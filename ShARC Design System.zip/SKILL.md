---
name: sharc-design
description: Use this skill to generate well-branded interfaces and assets for ShARC (Shift-Aware Capacitated Arc Routing — robust policy learning for HCARP under distribution shifts), either for production or throwaway prototypes/mocks/decks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Map
- `README.md` — product context, content & visual foundations, iconography, manifest. **Start here.**
- `colors_and_type.css` — the single source of truth for color, type, spacing, radius, shadow, and graph-viz tokens. Import or copy this into any artifact.
- `assets/` — brand marks (`sharc-mark.svg`, `sharc-wordmark.svg`).
- `preview/` — small specimen cards (type, color, spacing, components) — useful reference for how tokens look in use.
- `ui_kits/lab-console/` — the ShARC Lab Console UI kit: reusable React components (`Icon`, `Button`, `Panel`, `Metric`, `Slider`, `GraphCanvas`, `SweepChart`, `Sidebar`, …) and four interactive screens. Lift components from here when building app-like surfaces.

## House rules (quick reference)
- **Voice:** precise research-lab register; sentence case; mono ALL-CAPS only for status tokens/overlines; never use emoji; quote real numbers and notation (φ, α, CVaR₀.₁, ±30%).
- **Color:** warm paper + ink slate; azure primary; crimson = required/worst-case, amber = depot/warning, sky = nodes/info, moss = pass. Color carries data — use it sparingly.
- **Type:** IBM Plex Sans / Mono / Serif. Mono is a defining texture for all data.
- **Graph viz:** crimson required arcs, gray-dashed traversal, gold depot, sky nodes, azure route — always.
- **Surfaces:** flat warm paper, hairline borders, restrained radii (5/8/12px), soft cool-tinted shadows, no decorative gradients, no AI-slop tropes.
- **Icons:** Lucide (CDN), 1.75–2px stroke, outline.
