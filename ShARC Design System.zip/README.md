# ShARC — Design System

**ShARC** — *Shift-Aware Capacitated Arc Routing* — is a research system for **robust policy learning on the Hierarchical Capacitated Arc Routing Problem (HCARP) under distribution shifts**. This design system gives design agents and engineers the visual language, tokens, assets, and UI components to build well-branded interfaces, dashboards, figures, and decks for the project.

> The repository is a scientific computing / ML codebase and ships **no UI**. Every visual artifact here is created from the project's real domain concepts — graphs and arcs, distribution shifts, CVaR / regret minimization, severity sweeps, and the actual color coding used by the project's `graph_report.py`. The "ShARC Lab Console" UI kit is a proposed, illustrative product surface for the research, not a recreation of shipping software.

---

## What ShARC actually is

A garbage-collection (or delivery, or street-sweeping) company has to service **every required street segment** — an *arc* — in a city graph. On an average day, costs, demands, and road availability are stable. ShARC is built for the **bad days**: when travel costs spike, demand swells, or arcs become unavailable.

Most state-of-the-art arc-routing models are trained to generalize across "average" graph instances. ShARC instead deliberately trains a policy on **worst-case distribution shifts** so it degrades gracefully when things go wrong — minimizing *regret* and *worst-case tail cost* while staying competitive on nominal instances.

Concretely, the codebase:

- **Generates instances** from real road networks (`data_generation.py`, via OSMnx) — extracting a strongly-connected subgraph, sampling required arcs, assigning **priority classes** (1 ≫ 2 ≫ 3, lexicographic), and computing traversal time, service time, demand, and vehicle capacity.
- **Applies distribution shifts** along three axes (`env/shift.py`):
  `delta_demand` (±fractional demand change), `delta_cost` (±travel-cost change), and `p_availability` (probability each arc is reachable). Shifts ramp up via a **curriculum** or sample **uniformly**.
- **Trains a policy** (`models/policy.py`) — an attention encoder–decoder that conditions on a *budget* (running worst-case vehicle time) and the *shift context* — using **CVaR-REINFORCE** (`agents/cvar_agent.py`) to optimize the worst-α tail rather than the mean.
- **Evaluates robustness** with a **severity sweep** (`evaluation/severity_sweep.py`): both the shift-aware model (`cvar_shift`) and a risk-neutral baseline (`rn_nominal`) are run at severities φ ∈ {0, 0.2, 0.4, 0.6, 0.8, 1.0}, reporting mean `T_max` and `CVaR₀.₁(T_max)`.
- **Benchmarks against** classical metaheuristics (`baseline/`): ACO (ant colony), EA (evolutionary), ILS, LP, and cheapest-insertion.
- **Validates instances** (`graph_report.py`): renders the network (required arcs in **crimson**, traversal arcs in **gray dashed**, nodes in **sky blue**, depot in **gold**) and emits a PASS / WARNING / FAIL report.

### Key vocabulary
`HCARP` · `required arc` / `traversal (deadhead) arc` · `depot` · `priority class (T1/T2/T3)` · `distribution shift` · `severity φ` · `CVaR_α` (worst-α tail) · `regret` · `budget` (running max vehicle time) · `T_max` (makespan of worst vehicle) · `risk-neutral baseline` · `curriculum`.

---

## Sources

This design system was derived from one repository (read-only; reader may not have access):

- **GitHub — `PuffBear/ShARC`** · https://github.com/PuffBear/ShARC
  Internal title *ReMAR*: "Codes for testing benchmarks and building Robust Policy Learning for Arc Routing under Distribution Shifts." Files referenced: `data_generation.py`, `env/shift.py`, `env/hcarp_env.py`, `agents/cvar_agent.py`, `evaluation/{metrics,severity_sweep}.py`, `models/policy.py`, `baseline/meta.py`, `graph_report.py`, `training/configs/default.py`. The repo also contains paper sections (`section3_sharc.pdf`, `section6_sharc.pdf`).

**Explore the repository further** to build higher-fidelity designs — the source files are the ground truth for terminology, metrics, and the problem structure. There was no Figma file, codebase UI, or slide template provided.

---

## Content Fundamentals

How ShARC writes. The voice is that of a **precise research lab** — confident, technical, and unembellished. It reads like a methods section, not marketing.

- **Register:** academic / engineering. Define terms, then use them tersely. Prefer the exact term (`required arc`, `CVaR₀.₁`, `severity φ`) over a friendly paraphrase.
- **Person:** largely impersonal and third-person ("the policy conditions on…", "instances are sampled…"). Use **imperative** for tool/CLI surfaces ("Generate instances", "Run sweep"). Avoid "we"-marketing; "you" is acceptable only in direct UI instructions.
- **Casing:** **Sentence case** for headings and buttons ("Severity sweep", "Generate instances"). Reserve `ALL-CAPS MONO` for status tokens and overlines only (`PASS`, `WARNING`, `FAIL`, `RISK-NEUTRAL`).
- **Numbers & notation:** numbers are first-class. Quote metrics with units and precision (`CVaR₀.₁(T_max) = 1.284`, `φ = 0.6`, `α = 0.1`, `±30%`). Use real symbols: φ, α, ≫, ±, Δ. Subscripts where natural (T₁, T₂, T₃).
- **Emoji:** **never.** No emoji anywhere — it breaks the instrument-grade register.
- **Tone toward uncertainty:** honest and quantified. The product talks about "worst-case", "tail", "degradation", "regret" plainly rather than hiding them.

**Examples (in-voice):**
- Eyebrow: `DISTRIBUTION SHIFT`
- Heading: "Robust policy learning for arc routing under distribution shifts"
- Metric label: `CVaR₀.₁(T_max)` with caption "worst-10% makespan, lower is better"
- Button: "Run severity sweep" · "Generate instance" · "Compare to baseline"
- Status line (mono): `Status: PASS — no issues found.`
- Helper text: "Curriculum mode grows shift magnitude linearly over 1,000 steps."

**Avoid:** exclamation marks, hype adjectives ("blazing", "revolutionary"), vague claims without a number, and emoji.

---

## Visual Foundations

The aesthetic is an **instrument-grade research console**: warm paper surfaces, near-black slate ink, a disciplined azure primary, and a small set of *signal* accents lifted directly from the project's own graph renderer. It should feel like a well-typeset paper that became an interactive tool — calm, dense with real data, never decorative for its own sake.

- **Color vibe:** light, warm-neutral base (warm off-white paper `#FBFAF7`, near-black slate ink `#11151C`). One **primary** — **azure** `#1E63B4` (structure / routing). Three **signal** accents map 1:1 to `graph_report.py`: **crimson** `#D12C49` (required arcs / worst-case / critical), **amber/gold** `#D2941A` (depot / attention / warning), **sky** `#4F97C6` (nodes / info). Plus **moss** green for PASS/feasible and **iris** for a second categorical series. Accents are used sparingly and meaningfully — color carries data, it is not decoration.
- **Imagery:** the hero imagery *is the data* — node-link graphs, severity curves, route overlays. No stock photography, no people. Graphs use spring-style layouts, circular nodes, directional arcs. If photography is ever needed it should be cool, technical, infrastructural (roads, networks), but the default is generated visualization. No illustration set.
- **Type:** the **IBM Plex** superfamily — Plex Sans (UI/headings), **Plex Mono** (data, metrics, labels, code — heavily used), Plex Serif (optional long-form / abstract reading). Engineering-grade, coordinated, and not an overused web trope. Mono is a defining texture: metric values, axis labels, overlines, and status tokens are all mono.
- **Spacing & density:** 4px base grid. Comfortable but information-dense — closer to a dashboard than a marketing page. Generous outer padding, tight internal rhythm.
- **Backgrounds:** flat warm paper. **No gradients** as decoration (a gradient may appear only inside a data viz, e.g. a severity heat ramp). Optional very-subtle dot/grid texture on large empty canvases (graph background), never on content panels.
- **Corners:** restrained. `--radius-sm` (5px) for inputs/badges, `--radius-md` (8px) for buttons/cards, `--radius-lg` (12px) for large panels. Nothing pill-shaped except toggle/segment tracks and small count chips. Graph nodes are perfect circles.
- **Cards / panels:** white surface, 1px warm hairline border (`--line-200`), `--shadow-1` or `--shadow-2`. Cards lead with structure (a mono overline + a value) rather than imagery. Elevation is subtle and cool-tinted; reserve `--shadow-3/4` for menus, popovers, modals.
- **Borders:** hairline borders do most of the structural work (this is a "drawn", precise system). 1px `--line-200` default; 1.5px `--ink-200` for emphasis. Tables and metric grids use hairline dividers.
- **Shadows:** soft, low-spread, cool-tinted (`rgba(17,21,28,…)`). Elevation ladder `--shadow-1…4`. Focus uses a 3px azure ring (`--shadow-focus`), never a hard outline.
- **Transparency & blur:** minimal. A faint paper-tinted scrim behind modals; occasional `backdrop-blur` on a sticky toolbar over a scrolling graph. Never frosted-glass-everywhere.
- **Animation:** restrained and functional. Durations 120–220ms, easing `cubic-bezier(0.2, 0, 0, 1)` (decelerate). Fades + small (2–4px) translates. Data viz may animate values/curves on load (≤500ms ease-out). **No bounces, no infinite decorative loops** on content. Respect `prefers-reduced-motion`.
- **Hover states:** buttons darken one step (`--accent → --accent-hover`); ghost/secondary controls fill with `--bg-sunken`; rows tint with `--accent-soft`; links gain underline. Subtle, ~120ms.
- **Press states:** darken a second step (`--accent-press`) and/or `transform: translateY(1px)` or `scale(0.99)`. No large squish.
- **Focus:** visible 3px azure ring (`--shadow-focus`) on keyboard focus; 2px azure border on text inputs.
- **Layout rules:** fixed top bar + fixed left sidebar in app surfaces; content area scrolls. Max content measure ~72ch for prose. Metric tiles in responsive grids. Graph canvas gets the largest real estate.
- **Status & data encoding:** PASS = moss, WARNING = amber, FAIL = crimson, INFO = azure — consistent everywhere. Priority classes T1/T2/T3 = crimson/amber/sky. The "worst-case tail" is always crimson.

---

## Iconography

ShARC's source ships **no icon set, icon font, or SVG sprite** — it is a Python research codebase. The design system therefore standardizes on **Lucide** (https://lucide.dev), linked from CDN, as the substitute icon library. *(Substitution flagged: there is no original icon system to copy.)*

- **Why Lucide:** clean, consistent **1.75px stroke**, rounded line caps/joins, 24×24 grid — geometrically compatible with the precise, drawn, hairline-driven aesthetic and with IBM Plex's engineering tone. Outline (not filled) icons by default.
- **Usage:** stroke icons inherit `currentColor`; size 16/18/20px inline with text, 24px standalone. Keep stroke at 1.75–2px to match borders. Color icons with `--fg-2` by default, accent only to signal state.
- **Common glyphs in this domain:** `route`, `git-fork` / `share-2` (graph), `truck`, `map`, `waypoints`, `activity` (sweeps/curves), `shuffle` (shift), `gauge`, `sigma`, `circle-dot` (node/depot), `triangle-alert` (warning), `circle-check` (pass), `circle-x` (fail), `play`, `flask-conical` (experiments), `database`, `download`.
- **Logo / brand mark:** a custom geometric mark in `assets/` — three graph nodes joined by a routing arc, with a **gold depot** node, a **crimson** required-arc segment, and an **azure** route. Files: `assets/sharc-mark.svg` (icon) and `assets/sharc-wordmark.svg` (lockup: "Sh" in ink, "ARC" in azure). This is the one bespoke vector — everything else is Lucide.
- **Emoji / unicode:** **never** used as icons. Mathematical/typographic unicode (φ, α, ≫, ±, Δ, ₁₂₃) *is* used inline in text and labels, but only as notation, not as decoration.
- **Graph glyphs are not icons:** node-link diagrams are data visualization (see Visual Foundations), drawn with circles + arcs in the graph palette — never approximated with icons.

---

## Index — what's in this system

Root files:
- **`README.md`** — this file. Product context, sources, content + visual foundations, iconography, manifest.
- **`colors_and_type.css`** — the single source of truth for color, type, spacing, radius, shadow, and graph-viz tokens. Import everywhere.
- **`SKILL.md`** — Agent-Skills-compatible entry point for using this system in Claude Code.

Folders:
- **`assets/`** — brand marks: `sharc-mark.svg`, `sharc-wordmark.svg`.
- **`preview/`** — small HTML specimen cards that populate the Design System tab (type, color, spacing, components, brand). Each is registered as a reviewable asset.
- **`ui_kits/lab-console/`** — the **ShARC Lab Console** UI kit: an illustrative research-dashboard product surface (instance browser, shift studio, training monitor, severity sweep). `index.html` is the interactive demo; `*.jsx` are the reusable components.

There is **no `slides/`** folder — no slide template or deck was provided.

---

## Caveats

- **Fonts** load from Google Fonts CDN (IBM Plex Sans/Mono/Serif). No local font files are shipped; an internet connection is required, or download the woff2 files into a `fonts/` folder and add `@font-face` rules.
- **Icons** are substituted (Lucide via CDN) — the source has no icon system.
- The **brand mark** and the **entire UI kit** are *original, illustrative* designs grounded in the repo's concepts, since ShARC ships no UI, brand, or design definition. Treat them as a proposed direction to iterate on, not a recreation.
