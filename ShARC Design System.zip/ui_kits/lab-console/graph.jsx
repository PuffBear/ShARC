// ShARC Lab Console — data visualization: network graph + severity sweep chart.

// ---- Fixed demo instance (positions in a 640x420 viewBox) ----
const NODES = [
  { id: 0, x: 86, y: 342, depot: true },
  { id: 1, x: 178, y: 252 },
  { id: 2, x: 150, y: 120 },
  { id: 3, x: 276, y: 70 },
  { id: 4, x: 300, y: 200 },
  { id: 5, x: 244, y: 332 },
  { id: 6, x: 404, y: 300 },
  { id: 7, x: 432, y: 150 },
  { id: 8, x: 524, y: 88 },
  { id: 9, x: 566, y: 238 },
  { id: 10, x: 470, y: 384 },
  { id: 11, x: 350, y: 388 },
];
const REQUIRED = [[0,1],[1,2],[2,3],[3,4],[4,5],[1,4],[4,6],[6,7],[7,8],[8,9],[9,6],[6,10],[10,11],[11,5],[4,7]];
const TRAVERSAL = [[0,5],[3,8],[2,4],[9,10],[0,11],[5,6]];
// A serviced tour (node sequence) for the 'route' view
const TOUR = [0,1,2,3,4,7,8,9,6,10,11,5,0];

const N = (i) => NODES[i];

function GraphCanvas({ mode = 'instance', unavailable = [], height = 420 }) {
  const W = 640, H = 420;
  const isUn = (a, b) => unavailable.some(([x, y]) => x === a && y === b);
  return (
    <div className="graph-wrap">
      <div className="graph-dots" />
      <svg viewBox={`0 0 ${W} ${H}`} style={{ height: 'auto' }}>
        <defs>
          <marker id="arrReq" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M0 1 L9 5 L0 9 z" fill="var(--crimson-500)" />
          </marker>
          <marker id="arrRoute" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M0 1 L9 5 L0 9 z" fill="var(--azure-500)" />
          </marker>
        </defs>

        {/* traversal (deadhead) arcs */}
        {TRAVERSAL.map(([a, b], i) => (
          <line key={`t${i}`} x1={N(a).x} y1={N(a).y} x2={N(b).x} y2={N(b).y}
            stroke="var(--ink-300)" strokeWidth="1.6" strokeDasharray="4 5" />
        ))}

        {/* required arcs */}
        {mode !== 'route' && REQUIRED.map(([a, b], i) => {
          const un = isUn(a, b);
          return (
            <line key={`r${i}`} x1={N(a).x} y1={N(a).y} x2={N(b).x} y2={N(b).y}
              stroke="var(--crimson-500)" strokeWidth={un ? 2 : 2.8}
              strokeDasharray={un ? '3 6' : ''} opacity={un ? 0.35 : 1}
              markerEnd={un ? '' : 'url(#arrReq)'} />
          );
        })}

        {/* unavailable markers */}
        {mode === 'shift' && unavailable.map(([a, b], i) => {
          const mx = (N(a).x + N(b).x) / 2, my = (N(a).y + N(b).y) / 2;
          return (
            <g key={`u${i}`}>
              <circle cx={mx} cy={my} r="8" fill="var(--paper-000)" stroke="var(--crimson-400,#D12C49)" strokeWidth="1.5" />
              <path d={`M${mx-3} ${my-3} L${mx+3} ${my+3} M${mx+3} ${my-3} L${mx-3} ${my+3}`} stroke="var(--crimson-600)" strokeWidth="1.6" />
            </g>
          );
        })}

        {/* serviced route overlay */}
        {mode === 'route' && TOUR.slice(0, -1).map((a, i) => {
          const b = TOUR[i + 1];
          return (
            <line key={`q${i}`} x1={N(a).x} y1={N(a).y} x2={N(b).x} y2={N(b).y}
              stroke="var(--azure-500)" strokeWidth="3.2" markerEnd="url(#arrRoute)"
              className="fade-in" style={{ animationDelay: `${i * 45}ms` }} />
          );
        })}

        {/* nodes */}
        {NODES.map((n) => n.depot ? (
          <g key={n.id}>
            <circle cx={n.x} cy={n.y} r="11" fill="var(--amber-500)" stroke="var(--ink-900)" strokeWidth="2.4" />
          </g>
        ) : (
          <circle key={n.id} cx={n.x} cy={n.y} r="8.5" fill="var(--sky-300)" stroke="var(--azure-600)" strokeWidth="2.2" />
        ))}
      </svg>
      <div className="graph-legend">
        <span className="li"><span className="k" style={{ background: 'var(--amber-500)', borderRadius: '50%', width: 9, height: 9 }} />Depot</span>
        <span className="li"><span className="k" style={{ background: 'var(--crimson-500)' }} />Required</span>
        {mode === 'route'
          ? <span className="li"><span className="k" style={{ background: 'var(--azure-500)' }} />Route</span>
          : <span className="li"><span className="k" style={{ background: 'var(--ink-300)' }} />Traversal</span>}
      </div>
    </div>
  );
}

// ---- Severity sweep chart ----
// φ: 0..1; values = CVaR or mean T_max
const SWEEP = {
  phi: [0, 0.2, 0.4, 0.6, 0.8, 1.0],
  cvar_shift: [0.71, 0.79, 0.93, 1.05, 1.18, 1.284],
  rn_nominal: [0.69, 0.82, 1.04, 1.23, 1.47, 1.572],
};

function SweepChart({ height = 280 }) {
  const W = 560, H = 300, P = { t: 18, r: 16, b: 38, l: 46 };
  const xs = (i) => P.l + (i / (SWEEP.phi.length - 1)) * (W - P.l - P.r);
  const ymin = 0.6, ymax = 1.65;
  const ys = (v) => P.t + (1 - (v - ymin) / (ymax - ymin)) * (H - P.t - P.b);
  const path = (arr) => arr.map((v, i) => `${i ? 'L' : 'M'}${xs(i)} ${ys(v)}`).join(' ');
  const yticks = [0.7, 0.9, 1.1, 1.3, 1.5];
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 'auto' }}>
      {yticks.map((v) => (
        <g key={v}>
          <line x1={P.l} y1={ys(v)} x2={W - P.r} y2={ys(v)} stroke="var(--line-200)" strokeWidth="1" />
          <text x={P.l - 8} y={ys(v) + 3} textAnchor="end" fontFamily="var(--font-mono)" fontSize="10" fill="var(--ink-400)">{v.toFixed(1)}</text>
        </g>
      ))}
      {SWEEP.phi.map((p, i) => (
        <text key={p} x={xs(i)} y={H - P.b + 18} textAnchor="middle" fontFamily="var(--font-mono)" fontSize="10" fill="var(--ink-400)">{p.toFixed(1)}</text>
      ))}
      <text x={(P.l + W - P.r) / 2} y={H - 4} textAnchor="middle" fontFamily="var(--font-mono)" fontSize="10" fill="var(--ink-500)">severity φ</text>

      {/* baseline */}
      <path d={path(SWEEP.rn_nominal)} fill="none" stroke="var(--ink-400)" strokeWidth="2.2" strokeDasharray="5 4" />
      {SWEEP.rn_nominal.map((v, i) => <circle key={i} cx={xs(i)} cy={ys(v)} r="3.2" fill="var(--ink-500)" />)}
      {/* ours */}
      <path d={path(SWEEP.cvar_shift)} fill="none" stroke="var(--azure-500)" strokeWidth="2.6" />
      {SWEEP.cvar_shift.map((v, i) => <circle key={i} cx={xs(i)} cy={ys(v)} r="3.6" fill="var(--azure-500)" stroke="#fff" strokeWidth="1.4" />)}

      {/* legend */}
      <g transform={`translate(${P.l + 6}, ${P.t + 4})`}>
        <line x1="0" y1="6" x2="22" y2="6" stroke="var(--azure-500)" strokeWidth="2.6" />
        <text x="28" y="9" fontFamily="var(--font-mono)" fontSize="11" fill="var(--ink-800)">cvar_shift</text>
        <line x1="118" y1="6" x2="140" y2="6" stroke="var(--ink-400)" strokeWidth="2.2" strokeDasharray="5 4" />
        <text x="146" y="9" fontFamily="var(--font-mono)" fontSize="11" fill="var(--ink-500)">rn_nominal</text>
      </g>
    </svg>
  );
}

Object.assign(window, { GraphCanvas, SweepChart, SWEEP });
