// ShARC Lab Console — Training monitor screen (CVaR-REINFORCE).
const { useState: useStateT, useEffect: useEffectT, useRef: useRefT } = React;

function fmt(n, d = 3) { return n.toFixed(d); }

function TrainingScreen() {
  const [running, setRunning] = useStateT(false);
  const [epoch, setEpoch] = useStateT(142);
  const [log, setLog] = useStateT([
    { e: 140, cvar: 1.331, mean: 0.874, loss: 0.214 },
    { e: 141, cvar: 1.309, mean: 0.861, loss: 0.207 },
    { e: 142, cvar: 1.298, mean: 0.852, loss: 0.201 },
  ]);
  const logRef = useRefT(null);
  const last = log[log.length - 1];

  useEffectT(() => {
    if (!running) return;
    const id = setInterval(() => {
      setEpoch((e) => {
        const ne = e + 1;
        setLog((L) => {
          const prev = L[L.length - 1];
          const cvar = Math.max(1.18, prev.cvar - 0.004 - Math.random() * 0.004);
          const mean = Math.max(0.82, prev.mean - 0.002 - Math.random() * 0.002);
          const loss = Math.max(0.16, prev.loss - 0.002 - Math.random() * 0.002);
          return [...L, { e: ne, cvar, mean, loss }].slice(-9);
        });
        return ne;
      });
    }, 900);
    return () => clearInterval(id);
  }, [running]);

  useEffectT(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [log]);

  const pct = Math.min(100, Math.round((epoch / 200) * 100));

  return (
    <div className="fade-in">
      <div className="page-head">
        <div>
          <div className="eyebrow">agents/cvar_agent.py · CVaR-REINFORCE</div>
          <h1>Training</h1>
          <p>Optimising CVaR<sub>α</sub>[R] under a curriculum of distribution shifts. The policy is an attention encoder–decoder conditioned on budget and shift context.</p>
        </div>
        <div className="head-actions">
          {running
            ? <Button variant="danger" icon="stop" onClick={() => setRunning(false)}>Pause</Button>
            : <Button variant="primary" icon="play" onClick={() => setRunning(true)}>Resume</Button>}
          <Button variant="secondary" icon="download">Checkpoint</Button>
        </div>
      </div>

      <div className="grid cols-4" style={{ marginBottom: 16 }}>
        <Metric label="CVaR₀.₁" value={fmt(last.cvar)} dot="var(--crimson-500)" crit delta="14.8% vs RN" deltaDir="down" caption="worst-10% tail objective" />
        <Metric label="Mean reward" value={fmt(last.mean)} dot="var(--azure-500)" delta="6.1%" deltaDir="down" caption="−T_max average" />
        <Metric label="Policy loss" value={fmt(last.loss)} caption="CVaR-REINFORCE surrogate" />
        <Metric label="Epoch" value={`${epoch}`} unit="/ 200" caption={running ? 'training…' : 'paused'} dot={running ? 'var(--moss-500)' : 'var(--ink-300)'} />
      </div>

      <div className="split">
        <Panel title="Training log" icon="activity" sub={running ? 'live' : 'idle'}>
          <div style={{ marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', font: 'var(--text-mono-sm)', color: 'var(--fg-3)', marginBottom: 6 }}>
              <span>progress</span><span>{pct}%</span>
            </div>
            <ProgressBar pct={pct} />
          </div>
          <div className="log" ref={logRef}>
            {log.map((r) => (
              <div key={r.e}>
                <span className="ep">epoch {String(r.e).padStart(3, ' ')}</span>{'  '}
                <span className="k">cvar</span>=<span className="n">{fmt(r.cvar)}</span>{'  '}
                <span className="k">mean</span>=<span className="g">{fmt(r.mean)}</span>{'  '}
                <span className="k">loss</span>=<span className="n">{fmt(r.loss)}</span>
              </div>
            ))}
            {running && <div style={{ color: 'var(--ink-500)' }}>▌</div>}
          </div>
        </Panel>

        <Panel title="Run config" icon="sliders" sub="training/configs/default.py">
          <table className="tbl" style={{ margin: '-16px', width: 'calc(100% + 32px)' }}>
            <tbody>
              {[['agent', 'CVaRAgent'], ['α (CVaR level)', '0.1'], ['shift mode', 'curriculum'], ['warmup', '1000'], ['d_model · heads', '128 · 8'], ['enc layers', '3'], ['lr', '1e-4'], ['batch size', '32']].map(([k, v]) => (
                <tr key={k}><td className="name" style={{ color: 'var(--fg-2)' }}>{k}</td><td style={{ textAlign: 'right' }}>{v}</td></tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { TrainingScreen });
