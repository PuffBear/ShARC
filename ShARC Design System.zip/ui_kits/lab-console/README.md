# ShARC Lab Console — UI kit

An illustrative research-dashboard product surface for **ShARC** (robust policy learning for HCARP under distribution shifts). The ShARC repository ships **no UI** — this kit is an *original, grounded* proposal built entirely from the codebase's real concepts (instances & graphs, distribution shifts, CVaR-REINFORCE training, severity sweeps, graph-report validation). Treat it as a starting direction to iterate on, not a recreation of shipping software.

## Run it
Open `index.html`. It loads `../../colors_and_type.css` (foundations) + `kit.css` (kit styles), React 18 + Babel, then the component and screen files. Use the left sidebar to move between the four screens. The kit is a high-fidelity, mostly-cosmetic prototype — interactions are faked.

## Screens
- **Instances** (`screen-instances.jsx`) — browse validated HCARP instances, view the node-link graph (required arcs / traversal / depot) and a PASS/WARNING/FAIL validation report. Toggle the **Route** view to overlay a serviced tour. Click any instance in the list to load it.
- **Shift studio** (`screen-shift.jsx`) — perturb an instance along the three shift axes (demand, cost, availability). Lowering availability marks required arcs unavailable in the live preview; the shift context vector updates with the sliders.
- **Training** (`screen-training.jsx`) — CVaR-REINFORCE monitor with live metric tiles (CVaR₀.₁, mean reward, loss), a streaming training log, progress, and the run config. Press **Resume** to simulate live training.
- **Severity sweep** (`screen-sweep.jsx`) — the paper's central figure: mean T_max vs severity φ for `cvar_shift` (ours) and `rn_nominal` (baseline), with metric tiles and a results table.

## Files
| File | Role |
|---|---|
| `index.html` | App shell, routing between screens, mounts React |
| `kit.css` | Kit-level component styles (imports foundations) |
| `icons.jsx` | `Icon` (Lucide glyphs) + `BrandMark` |
| `components.jsx` | `Button`, `Panel`, `Badge`, `Chip`, `Metric`, `Field`, `Select`, `Segmented`, `Slider`, `ProgressBar` |
| `graph.jsx` | `GraphCanvas` (node-link instance/route/shift views) + `SweepChart` |
| `chrome.jsx` | `Sidebar`, `TopBar` |
| `screen-*.jsx` | The four screens |

## Conventions
- Components export to `window` via `Object.assign` so the separate Babel scripts share scope. Each file uses uniquely-named locals (no bare `const styles`).
- All color/type/spacing comes from CSS variables in `colors_and_type.css` — no hard-coded values beyond the SVG graph palette (which mirrors the tokens).
- Graph visualization uses the authentic `graph_report.py` coding: crimson required arcs, gray-dashed traversal, gold depot, sky nodes, azure route overlay.

## Coverage & caveats
- This is a **proposed** surface — there is no source UI to match pixel-for-pixel. Component coverage (nav, top bar, panels, metrics, tables, sliders, badges, graph canvas, chart) is the priority.
- Numbers are illustrative but internally consistent and in-range with the codebase defaults (α=0.1, ±30% shifts, φ∈{0..1}).
- Icons are Lucide (substituted — the repo has none). Fonts are IBM Plex via Google Fonts CDN.
