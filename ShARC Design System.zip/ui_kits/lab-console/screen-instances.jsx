// ShARC Lab Console — Instances screen.
const { useState: useStateI } = React;

const INSTANCES = [
  { id: 'gdb-04', arcs: 118, req: 64, M: 5, status: 'PASS' },
  { id: 'gdb-11', arcs: 96, req: 61, M: 5, status: 'PASS' },
  { id: 'osm-piedmont', arcs: 142, req: 70, M: 5, status: 'WARNING' },
  { id: 'osm-rnd-7731', arcs: 88, req: 60, M: 5, status: 'PASS' },
  { id: 'osm-rnd-2049', arcs: 203, req: 70, M: 6, status: 'FAIL' },
  { id: 'gdb-19', arcs: 110, req: 63, M: 5, status: 'PASS' },
];

const REPORTS = {
  PASS: ['Status: PASS', 'Strongly connected: yes', 'Triangle inequality: holds (100 samples)', 'Max demand ≤ capacity: ok', 'No issues found.'],
  WARNING: ['Status: WARNING', 'Strongly connected: yes', 'Triangle inequality: holds', 'Zero/negative costs detected on 2 arcs', 'Proceed with caution.'],
  FAIL: ['Status: FAIL', 'Strongly connected: yes', 'Infeasible: max demand 1.06 exceeds capacity 1.00', 'Triangle inequality: holds', 'Instance rejected.'],
};

function ReportBlock({ status }) {
  const lines = REPORTS[status];
  const head = lines[0];
  return (
    <div className="report">
      <div className="ln" style={{ marginBottom: 8 }}><Badge status={status}>{head}</Badge></div>
      {lines.slice(1).map((l, i) => (
        <div className="ln" key={i}><span className="mk" style={{ color: i === lines.length - 2 ? 'var(--ink-400)' : 'var(--ink-300)' }}>{i === lines.length - 2 ? '›' : '·'}</span>{l}</div>
      ))}
    </div>
  );
}

function InstancesScreen() {
  const [sel, setSel] = useStateI('gdb-04');
  const [view, setView] = useStateI('Instance');
  const inst = INSTANCES.find((x) => x.id === sel);
  return (
    <div className="fade-in">
      <div className="page-head">
        <div>
          <div className="eyebrow">Dataset · data/eval_dataset</div>
          <h1>Instances</h1>
          <p>Validated HCARP instances sampled from OSM road networks. Required arcs are servicing tasks; the depot is fixed at node 0.</p>
        </div>
        <div className="head-actions">
          <Button variant="secondary" icon="refresh">Re-validate</Button>
          <Button variant="primary" icon="plus">Generate instance</Button>
        </div>
      </div>

      <div className="split">
        <Panel title={`Instance ${sel}`} icon="waypoints" sub={`|A| ${inst.arcs} · |Ar| ${inst.req} · |M| ${inst.M}`}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
            <Segmented value={view} options={['Instance', 'Route']} onChange={setView} />
            <div style={{ display: 'flex', gap: 8 }}>
              <Chip color="var(--class-1)">T₁</Chip><Chip color="var(--class-2)">T₂</Chip><Chip color="var(--class-3)">T₃</Chip>
            </div>
          </div>
          <GraphCanvas mode={view === 'Route' ? 'route' : 'instance'} />
        </Panel>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Panel title="Validation report" icon="check" style={{ overflow: 'hidden' }}>
            <ReportBlock status={inst.status} />
          </Panel>
          <Panel title="Browse" icon="search" sub={`${INSTANCES.length} loaded`}>
            <div className="ilist" style={{ margin: '-16px' }}>
              {INSTANCES.map((x) => (
                <div key={x.id} className={`irow ${x.id === sel ? 'sel' : ''}`} onClick={() => { setSel(x.id); setView('Instance'); }}>
                  <Icon name="dot" size={15} style={{ color: x.id === sel ? 'var(--azure-600)' : 'var(--ink-300)' }} />
                  <span className="nm">{x.id}</span>
                  <span className="meta">{x.arcs}a · {x.req}r</span>
                  <Badge status={x.status} />
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { InstancesScreen });
