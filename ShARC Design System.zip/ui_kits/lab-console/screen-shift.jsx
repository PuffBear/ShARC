// ShARC Lab Console — Shift studio screen.
const { useState: useStateS } = React;

// Map a severity to which required arcs go unavailable (deterministic, illustrative)
const UNAVAIL_POOL = [[8,9],[9,6],[10,11],[6,7],[2,3],[11,5],[4,7]];

function ShiftScreen() {
  const [demand, setDemand] = useStateS(0.30);
  const [cost, setCost] = useStateS(0.30);
  const [avail, setAvail] = useStateS(0.70);
  const [mode, setMode] = useStateS('Curriculum');
  const [warmup, setWarmup] = useStateS(1000);

  const dropP = 1 - avail;
  const nDrop = Math.round(dropP / 0.3 * UNAVAIL_POOL.length);
  const unavailable = UNAVAIL_POOL.slice(0, Math.min(nDrop, UNAVAIL_POOL.length));

  return (
    <div className="fade-in">
      <div className="page-head">
        <div>
          <div className="eyebrow">env/shift.py · ShiftScheduler</div>
          <h1>Shift studio</h1>
          <p>Perturb instances along three axes. The policy conditions on the shift context [Δdemand, Δcost, p_availability] so it can adapt to the regime it is dispatched in.</p>
        </div>
        <div className="head-actions">
          <Button variant="secondary" icon="refresh">Reset</Button>
          <Button variant="primary" icon="shuffle">Resample batch</Button>
        </div>
      </div>

      <div className="split">
        <Panel title="Shifted instance preview" icon="waypoints" sub={`p_avail = ${avail.toFixed(2)} · ${unavailable.length} arc(s) unavailable`}>
          <GraphCanvas mode="shift" unavailable={unavailable} />
        </Panel>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Panel title="Shift parameters" icon="sliders">
            <Slider name="Demand shift" value={demand} min={0} max={0.6} step={0.01}
              fmt={(v) => `±${Math.round(v * 100)}%`} color="var(--crimson-500)" onChange={setDemand} />
            <Slider name="Cost shift" value={cost} min={0} max={0.6} step={0.01}
              fmt={(v) => `±${Math.round(v * 100)}%`} color="var(--amber-500)" onChange={setCost} />
            <Slider name="Availability" value={avail} min={0.4} max={1} step={0.01}
              fmt={(v) => v.toFixed(2)} color="var(--azure-500)" onChange={setAvail} />
            <Field label="Schedule mode">
              <Segmented value={mode} options={['Curriculum', 'Uniform']} onChange={setMode} />
            </Field>
            {mode === 'Curriculum' && (
              <Field label="Warmup steps" hint="Magnitude grows linearly to full over this many batches.">
                <input className="input" type="number" value={warmup} onChange={(e) => setWarmup(+e.target.value)} />
              </Field>
            )}
          </Panel>

          <Panel title="Shift context" icon="target" sub="policy conditioning">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
              <Metric label="Δ demand" value={`±${Math.round(demand * 100)}%`} dot="var(--crimson-500)" />
              <Metric label="Δ cost" value={`±${Math.round(cost * 100)}%`} dot="var(--amber-500)" />
              <Metric label="p_avail" value={avail.toFixed(2)} dot="var(--azure-500)" />
            </div>
            <div style={{ marginTop: 12, font: 'var(--text-mono-sm)', color: 'var(--fg-3)' }}>
              <code>context = [{demand.toFixed(2)}, {cost.toFixed(2)}, {dropP.toFixed(2)}]</code>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ShiftScreen });
