// ShARC Lab Console — shared primitives.
const { useState } = React;

function Button({ variant = 'secondary', size, icon, children, ...rest }) {
  const cls = ['btn', `btn-${variant}`, size === 'sm' ? 'btn-sm' : ''].join(' ');
  return (
    <button className={cls} {...rest}>
      {icon && <Icon name={icon} size={15} />}
      {children}
    </button>
  );
}

function Panel({ title, sub, icon, children, style }) {
  return (
    <section className="panel" style={style}>
      {title && (
        <div className="panel-h">
          {icon && <Icon name={icon} className="panel-icon" size={16} />}
          <span className="t">{title}</span>
          {sub && <span className="sub">{sub}</span>}
        </div>
      )}
      <div className="panel-b">{children}</div>
    </section>
  );
}

const STATUS = {
  PASS: { cls: 'badge-pass', dot: 'var(--moss-500)' },
  WARNING: { cls: 'badge-warn', dot: 'var(--amber-600)' },
  FAIL: { cls: 'badge-fail', dot: 'var(--crimson-600)' },
  INFO: { cls: 'badge-info', dot: 'var(--azure-500)' },
  NOMINAL: { cls: 'badge-info', dot: 'var(--azure-500)' },
  COMPLETE: { cls: 'badge-pass', dot: 'var(--moss-500)' },
};

function Badge({ status, children }) {
  const s = STATUS[status] || STATUS.INFO;
  return (
    <span className={`badge ${s.cls}`}>
      <span className="dot" style={{ background: s.dot }} />
      {children || status}
    </span>
  );
}

function Chip({ children, color }) {
  if (color) return <span className="chip chip-pri" style={{ background: color }}>{children}</span>;
  return <span className="chip">{children}</span>;
}

function Metric({ label, value, unit, delta, deltaDir, caption, dot, crit }) {
  return (
    <div className={`metric ${crit ? 'crit' : ''}`}>
      <div className="ovr">
        {dot && <span className="dot" style={{ background: dot }} />}
        {label}
      </div>
      <div className="val">{value}{unit && <small> {unit}</small>}</div>
      {delta && <span className={`delta ${deltaDir}`}>{deltaDir === 'down' ? '▼' : '▲'} {delta}</span>}
      {caption && <div className="cap">{caption}</div>}
    </div>
  );
}

function Field({ label, hint, children }) {
  return (
    <div className="field">
      {label && <label>{label}</label>}
      {children}
      {hint && <span className="hint">{hint}</span>}
    </div>
  );
}

function Select({ value, options, onChange }) {
  return (
    <div className="select">
      <select className="input" value={value} onChange={(e) => onChange && onChange(e.target.value)}>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
      <Icon name="chevronDown" size={14} />
    </div>
  );
}

function Segmented({ value, options, onChange }) {
  return (
    <div className="seg">
      {options.map((o) => (
        <button key={o} className={value === o ? 'on' : ''} onClick={() => onChange && onChange(o)}>{o}</button>
      ))}
    </div>
  );
}

function Slider({ name, value, min, max, step, fmt, onChange, ticks, color = 'var(--azure-500)' }) {
  return (
    <div className="slider">
      <div className="row">
        <span className="nm">{name}</span>
        <span className="vl" style={{ color: color === 'var(--azure-500)' ? 'var(--azure-700)' : color }}>{fmt ? fmt(value) : value}</span>
      </div>
      <input
        type="range" min={min} max={max} step={step} value={value}
        style={{ accentColor: color }}
        onChange={(e) => onChange && onChange(parseFloat(e.target.value))}
      />
      {ticks && <div className="ticks">{ticks.map((t) => <span key={t}>{t}</span>)}</div>}
    </div>
  );
}

function ProgressBar({ pct }) {
  return <div className="bar"><div className="fill" style={{ width: `${pct}%` }} /></div>;
}

Object.assign(window, { Button, Panel, Badge, Chip, Metric, Field, Select, Segmented, Slider, ProgressBar });
