// ShARC Lab Console — Severity sweep screen (the paper's central figure).
const { useState: useStateW } = React;

function SweepScreen() {
  const [metric, setMetric] = useStateW('CVaR₀.₁(T_max)');
  const rows = SWEEP.phi.map((p, i) => ({
    phi: p,
    ours: SWEEP.cvar_shift[i],
    base: SWEEP.rn_nominal[i],
    gap: ((SWEEP.rn_nominal[i] - SWEEP.cvar_shift[i]) / SWEEP.rn_nominal[i] * 100),
  }));
  const worstGap = rows[rows.length - 1].gap;

  return (
    <div className="fade-in">
      <div className="page-head">
        <div>
          <div className="eyebrow">evaluation/severity_sweep.py</div>
          <h1>Severity sweep</h1>
          <p>Both policies evaluated at φ ∈ {'{'}0, …, 1{'}'} on a held-out set. The shift-aware model holds its makespan as severity climbs; the risk-neutral baseline degrades sharply in the tail.</p>
        </div>
        <div className="head-actions">
          <Button variant="secondary" icon="download">Export CSV</Button>
          <Button variant="primary" icon="play">Re-run sweep</Button>
        </div>
      </div>

      <div className="grid cols-3" style={{ marginBottom: 16 }}>
        <Metric label="CVaR₀.₁ @ φ=1.0" value="1.284" dot="var(--crimson-500)" crit delta={`${worstGap.toFixed(1)}% vs baseline`} deltaDir="down" caption="worst-case severity" />
        <Metric label="Mean T_max" value="0.842" dot="var(--azure-500)" delta="6.1%" deltaDir="down" caption="averaged over φ" />
        <Metric label="Robustness gap" value={`${worstGap.toFixed(0)}%`} caption="tail improvement at φ=1.0" />
      </div>

      <div className="split">
        <Panel title="Mean T_max vs severity φ" icon="activity" sub={metric}>
          <SweepChart />
        </Panel>
        <Panel title="Results" icon="sigma" sub="α = 0.1 · n = 240">
          <table className="tbl" style={{ margin: '-16px', width: 'calc(100% + 32px)' }}>
            <thead><tr><th>φ</th><th style={{ textAlign: 'right' }}>cvar_shift</th><th style={{ textAlign: 'right' }}>rn_nominal</th><th style={{ textAlign: 'right' }}>gap</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.phi}>
                  <td className="name">{r.phi.toFixed(1)}</td>
                  <td className="win" style={{ textAlign: 'right' }}>{r.ours.toFixed(3)}</td>
                  <td style={{ textAlign: 'right', color: 'var(--fg-2)' }}>{r.base.toFixed(3)}</td>
                  <td style={{ textAlign: 'right', color: r.gap > 0 ? 'var(--moss-500)' : 'var(--ink-400)' }}>{r.gap > 0 ? '−' : ''}{Math.abs(r.gap).toFixed(1)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { SweepScreen });
