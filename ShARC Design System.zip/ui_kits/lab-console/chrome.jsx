// ShARC Lab Console — app chrome: sidebar + top bar.
const NAV = [
  { id: 'instances', label: 'Instances', icon: 'waypoints', count: '24' },
  { id: 'shift', label: 'Shift studio', icon: 'shuffle' },
  { id: 'training', label: 'Training', icon: 'flask' },
  { id: 'sweep', label: 'Severity sweep', icon: 'activity' },
];

function Sidebar({ active, onNav }) {
  return (
    <aside className="sidebar">
      <div className="sb-brand">
        <BrandMark size={28} />
        <span className="word">Sh<span className="arc">ARC</span></span>
      </div>
      <div className="sb-sec">Workspace</div>
      {NAV.map((n) => (
        <button key={n.id} className={`nav-item ${active === n.id ? 'active' : ''}`} onClick={() => onNav(n.id)}>
          <Icon name={n.icon} size={18} />
          {n.label}
          {n.count && <span className="count">{n.count}</span>}
        </button>
      ))}
      <div className="sb-sec">Resources</div>
      <button className="nav-item"><Icon name="database" size={18} />Datasets</button>
      <button className="nav-item"><Icon name="cpu" size={18} />Checkpoints</button>
      <div className="sb-spacer" />
      <div className="sb-foot">
        ReMAR · HCARP<br />robust policy learning<br />
        <span style={{ color: 'var(--ink-400)' }}>build a2f2ca9</span>
      </div>
    </aside>
  );
}

function TopBar({ title, sub, children }) {
  return (
    <header className="topbar">
      <span className="tb-title">{title}</span>
      {sub && <span className="tb-sub">{sub}</span>}
      <span className="tb-spacer" />
      {children}
      <span className="run-pill"><span className="pulse" />cvar_shift · epoch 142</span>
    </header>
  );
}

Object.assign(window, { Sidebar, TopBar, NAV });
